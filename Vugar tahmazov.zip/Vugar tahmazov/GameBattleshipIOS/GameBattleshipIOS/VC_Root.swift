//
//  ViewController.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 02/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class VC_Root: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


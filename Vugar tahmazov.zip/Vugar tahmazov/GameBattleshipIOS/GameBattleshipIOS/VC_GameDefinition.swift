//
//  VC_GameDefinition.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 06/05/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class VC_GameDefinition: UIViewController {
    private var managerSettings = ManagerSettings.sharedInstance
    
    @IBOutlet weak var textFieldName: UITextField!
    @IBOutlet weak var textFieldDescription: UITextField!
    @IBOutlet weak var textFieldRows: UITextField!
    @IBOutlet weak var textFieldColumns: UITextField!
    @IBOutlet weak var labelShipSetName: UILabel!
    
    private var gameDefinition: GameDefinition!
    var viewMode = ViewMode.undefined
    var parentController: TVC_GameDefinitions!
    var indexGameDefinition: Int?
    var indexShipSet: Int?
    
    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func viewDidLoad() {
        super.viewDidLoad()

        switch viewMode {
        case .add:
            textFieldName.text = nil
            textFieldDescription.text = nil
            textFieldRows.text = nil
            textFieldColumns.text = nil
            labelShipSetName.text = nil
            
            gameDefinition = GameDefinition()
        case .edit:
            textFieldName.text = managerSettings.gameDefinitions[indexGameDefinition!].name
            textFieldDescription.text = managerSettings.gameDefinitions[indexGameDefinition!].description
            textFieldRows.text = "\(managerSettings.gameDefinitions[indexGameDefinition!].rows)"
            textFieldColumns.text = "\(managerSettings.gameDefinitions[indexGameDefinition!].columns)"
            
            let shipSetUUID = managerSettings.gameDefinitions[indexGameDefinition!].shipSetUUID!
            let indexShipSet = managerSettings.getShipSetIndex(forShipSetUUID: shipSetUUID)
            
            labelShipSetName.text = "\(managerSettings.shipSets[indexShipSet!].name ?? AppStrings.unknown)"
            
            gameDefinition = managerSettings.gameDefinitions[indexGameDefinition!].copy() as? GameDefinition
        default:
            print(StaticVariable.Error + ": Bad view mode")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == StaticVariable.SegueFromGameDefinitionToShipSets) {
            // targetController TVC_ShipSets is "hidden" behind destVC UINavigationController
            if let destVC = segue.destination as? UINavigationController,
                let targetController = destVC.topViewController as? TVC_ShipSets {
                targetController.viewMode = .noneditable
                targetController.indexShipSet = indexShipSet
            }
        }
    }
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    @IBAction func buttonAccceptPress(_ sender: UIButton) {
        if let name = textFieldName.text,
            let rows = textFieldRows.text,
            let columns = textFieldColumns.text,
            let indexShipSet = indexShipSet,
            !name.isEmpty &&
            !rows.isEmpty &&
            !columns.isEmpty &&
            Int(rows)! > 0 &&
            Int(columns)! > 0
        {
            gameDefinition.name = textFieldName.text
            gameDefinition.description = textFieldDescription.text
            gameDefinition.rows = Int(rows)!
            gameDefinition.columns = Int(columns)!
            gameDefinition.shipSetUUID = managerSettings.shipSets[indexShipSet].uuid
            
            if indexGameDefinition != nil {
                managerSettings.gameDefinitions[indexGameDefinition!] = gameDefinition
            } else {
                managerSettings.gameDefinitions.append(gameDefinition)
            }
            
            managerSettings.saveGameDefinitions()
            
            self.navigationController?.popViewController(animated: true)
            parentController.tableView.reloadData()
        } else {
            // BEGIN action dialog
            let alert = UIAlertController(title: AppStrings.information,
                                          message: AppStrings.missingGameDefinitionInformations,
                                          preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: AppStrings.ok,
                                          style: .default,
                                          handler: { (_) in
            }))
            
            self.present(alert, animated: true, completion: nil)
            // END action dialog
        }
    }
    
    @IBAction func buttonCancelPress(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func unwindFromShipSets(segue: UIStoryboardSegue){
        if let fromVC = segue.source as? TVC_ShipSets {
            indexShipSet = fromVC.indexShipSet
            refreshView()
        }
    }
    // END Actions
    
    // MARK: - My functions
    // BEGIN My functions
    private func refreshView() {
        if indexShipSet != nil {
            labelShipSetName.text = managerSettings.shipSets[indexShipSet!].name
        } else {
            labelShipSetName.text = nil
        }
    }
    // END My functions
}

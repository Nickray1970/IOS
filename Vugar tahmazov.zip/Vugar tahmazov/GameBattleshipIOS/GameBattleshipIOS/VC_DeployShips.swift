//
//  VC_DeployShips.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 21/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class VC_DeployShips: UIViewController {
    private var managerGame = ManagerGame.sharedInstance

    // MARK: - Overriden functions
    // BEGIN Overriden functions
    
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    @IBAction func buttonAutomaticallyPress(_ sender: UIButton) {
        if tryToDeployShips() {
            let vc = (self.storyboard?.instantiateViewController(withIdentifier: StaticVariable.ID_VC_Play) as! VC_Play)
            vc.modalPresentationStyle = .overFullScreen
            managerGame.playLoopStage = .playerShoot
            managerGame.visibleView = VC_Play.VisibleView.opponentShips
            self.present(vc, animated: true, completion: nil)
        } else {
            // BEGIN action dialog
            let alert = UIAlertController(title: AppStrings.information,
                                          message: AppStrings.unsuccessfulShipDeployment,
                                          preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: AppStrings.ok,
                                          style: .default,
                                          handler: { (_) in
            }))
            
            self.present(alert, animated: true, completion: nil)
            // END action dialog
        }
    }
    
    @IBAction func buttonManuallyPress(_ sender: UIButton) {
        // BEGIN action dialog
        let alert = UIAlertController(title: AppStrings.information,
                                      message: AppStrings.notYetImplemented,
                                      preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: AppStrings.ok,
                                      style: .default,
                                      handler: { (_) in
        }))
        
        self.present(alert, animated: true, completion: nil)
        // END action dialog
    }
    
    @IBAction func buttonBackPress(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    // END Actions
    
    // MARK: - My functions
    // BEGIN My functions
    private func tryToDeployShips() -> Bool {
        let opponentReady = managerGame.engine.shipsAutoSetup(maxTriesPerShip: 20,
                                                              who: .opponent)
        let playerReady = managerGame.engine.shipsAutoSetup(maxTriesPerShip: 20,
                                                            who: .player)
        if opponentReady, playerReady {
            return true
        }
        
        return false
    }
    // END My functions
}

//
//  GameDefinition.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 08/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class GameDefinition: Codable {
    var name: String?
    var description: String?
    var rows = 0
    var columns = 0
    var shipSetUUID: UUID?
    
    init() {
        self.name = ""
        self.description = ""
    }
    
    init(name: String?, description:String?, rows: Int, columns: Int, shipSetUUID: UUID) {
        self.name = name
        self.description = description
        self.rows = rows
        self.columns = columns
        self.shipSetUUID = shipSetUUID
    }
}

//extension GameDefinition: Codable {
//    
//}

extension GameDefinition: NSCopying {
    func copy(with zone: NSZone? = nil) -> Any {
        let copy = GameDefinition(name: name,
                                  description: description,
                                  rows: rows,
                                  columns: columns,
                                  shipSetUUID: shipSetUUID!)
        return copy
    }
}

//
//  VC_Play_Player_Ships.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 21/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class VC_Play_Player_Ships: UIViewController {
    @IBOutlet weak var labelMessage: UILabel!
    @IBOutlet weak var buttonOK: UIButton!
    @IBOutlet weak var viewGameBoard: V_GameBoard!
    
    private var managerGame = ManagerGame.sharedInstance
    
    var vcPlay: VC_Play!
    
    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func viewDidLoad() {
        super.viewDidLoad()
        viewGameBoard.who = EngineGameBattleship.Who.player
        managerGame.playerViewGameBoard = viewGameBoard
        labelMessage.text = ""
    }
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    @IBAction func buttonOKPress(_ sender: UIButton) {
        managerGame.messageToDisplayInNextView = ""
        vcPlay.nextStage()
    }
    // END Actions
    
    // MARK: - My functions
    // BEGIN My functions
    func updateMessage() {
        labelMessage.text = managerGame.messageToDisplayInNextView
    }
    // END My functions
}

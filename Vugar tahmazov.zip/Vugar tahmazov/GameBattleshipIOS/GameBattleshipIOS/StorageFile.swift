//
//  StorageFile.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 07/05/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class StorageFile {
    static let sharedInstance = StorageFile()
    
    private struct FileNames {
        static let boardOpponent = "board_opponent.json"
        static let boardPlayer = "board_player.json"
        static let settings = "settings.json"
        static let shipSets = "ship_sets.json"
        static let gameDefinitions = "game_definitions.json"
    }
    
    enum DataType {
        case unknown, boardOpponent, boardPlayer, gameDefinitions, settings, shipSets
    }
    
    func getPath(type: DataType) -> URL? {
        if let fileName = getFileName(forType: type) {
            let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            return documentDirectory!.appendingPathComponent(fileName)
        }
        
        return nil
    }
    
    func loadBoard(of: DataType) -> Board? {
        let pathUrl = getPath(type: of)
        
        if let pathUrl = pathUrl {
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: pathUrl.path) {
                do {
                    let jsonFileContents = try String(contentsOf: pathUrl, encoding: .utf8)
                    let board = try JSONDecoder().decode(Board.self, from: jsonFileContents.data(using: .utf8)!)
                    
                    return board
                } catch let error {
                    print(StaticVariable.Error + ": load encoding error: ", error)
                }
            } else {
                print(StaticVariable.Info + ": file does not exists: ", pathUrl.path)
            }
        }
        
        return nil
    }
    
    func loadGameDefinitions() -> [GameDefinition]? {
        let pathUrl = getPath(type: .gameDefinitions)
        
        if let pathUrl = pathUrl {
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: pathUrl.path) {
                do {
                    let jsonFileContents = try String(contentsOf: pathUrl, encoding: .utf8)
                    let array = try JSONDecoder().decode([GameDefinition].self, from: jsonFileContents.data(using: .utf8)!)
                    
                    return array
                } catch let error {
                    print(StaticVariable.Error + ": load encoding error: ", error)
                }
            } else {
                print(StaticVariable.Info + ": file does not exists: ", pathUrl.path)
            }
        }
        
        return nil
    }
    
    func loadSettings() -> ManagerSettings.Settings? {
        let pathUrl = getPath(type: .settings)
        
        if let pathUrl = pathUrl {
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: pathUrl.path) {
                do {
                    let jsonFileContents = try String(contentsOf: pathUrl, encoding: .utf8)
                    let settings = try JSONDecoder().decode(ManagerSettings.Settings.self, from: jsonFileContents.data(using: .utf8)!)
                    
                    return settings
                } catch let error {
                    print(StaticVariable.Error + ": load encoding error: ", error)
                }
            } else {
                print(StaticVariable.Info + ": file does not exists: ", pathUrl.path)
            }
        }
        
        return nil
    }
    
    func loadShipSets() -> [ShipSet]? {
        let pathUrl = getPath(type: .shipSets)
        
        if let pathUrl = pathUrl {
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: pathUrl.path) {
                do {
                    let jsonFileContents = try String(contentsOf: pathUrl, encoding: .utf8)
                    let array = try JSONDecoder().decode([ShipSetStorage].self, from: jsonFileContents.data(using: .utf8)!)
                    
                    var shipSets = [ShipSet]()
                    for shipSetStorage in array {
                        let shipSet = ShipSet(name: shipSetStorage.name,
                                              description: shipSetStorage.description,
                                              uuid: shipSetStorage.uuid)
                        shipSet.addShips(ships: shipSetStorage.ships)
                        shipSets.append(shipSet)
                    }
                    return shipSets
                } catch let error {
                    print(StaticVariable.Error + ": load encoding error: ", error)
                }
            } else {
                print(StaticVariable.Info + ": file does not exists: ", pathUrl.path)
            }
        }
        
        return nil
    }
    
    func save(board: Board, of: DataType) {
        let pathUrl = getPath(type: of)
        
        if let pathUrl = pathUrl {
            let jsonEncoder = JSONEncoder()
            do {
                let jsonData = try jsonEncoder.encode(board)
                let jsonString = String(data: jsonData, encoding: .utf8)
                
                try jsonString?.write(to: pathUrl, atomically: true, encoding: .utf8)
            } catch let error {
                print(StaticVariable.Error + ": save encoding error: ", error)
            }
        }
    }
    
    func save(gameDefinitions: [GameDefinition]) {
        let pathUrl = getPath(type: .gameDefinitions)
        
        if let pathUrl = pathUrl {
            let jsonEncoder = JSONEncoder()
            do {
                let jsonData = try jsonEncoder.encode(gameDefinitions)
                let jsonString = String(data: jsonData, encoding: .utf8)
                
                try jsonString?.write(to: pathUrl, atomically: true, encoding: .utf8)
            } catch let error {
                print(StaticVariable.Error + ": save encoding error: ", error)
            }
        }
    }
    
    func save(settings: ManagerSettings.Settings) {
        let pathUrl = getPath(type: .settings)
        
        if let pathUrl = pathUrl {
            let jsonEncoder = JSONEncoder()
            do {
                let jsonData = try jsonEncoder.encode(settings)
                let jsonString = String(data: jsonData, encoding: .utf8)
                
                try jsonString?.write(to: pathUrl, atomically: true, encoding: .utf8)
            } catch let error {
                print(StaticVariable.Error + ": save encoding error: ", error)
            }
        }
    }
    
    func save(shipSets: [ShipSet]) {
        let pathUrl = getPath(type: .shipSets)
        
        if let pathUrl = pathUrl {
            print(StaticVariable.Info + ": \(pathUrl.absoluteString)")
            
            var shipSetsStorage = [ShipSetStorage]()
            for shipSet in shipSets {
                let shipSetStorage = ShipSetStorage(name: shipSet.name,
                                                    description: shipSet.description,
                                                    uuid: shipSet.uuid,
                                                    ships: shipSet.getShipAll())
                shipSetsStorage.append(shipSetStorage)
            }
            
            let jsonEncoder = JSONEncoder()
            do {
                let jsonData = try jsonEncoder.encode(shipSetsStorage)
                let jsonString = String(data: jsonData, encoding: .utf8)
                
                try jsonString?.write(to: pathUrl, atomically: true, encoding: .utf8)
            } catch let error {
                print(StaticVariable.Error + ": save encoding error: ", error)
            }
        }
    }
    
    private func getFileName(forType type: DataType) -> String? {
        switch type {
        case .boardOpponent:
            return FileNames.boardOpponent
        case .boardPlayer:
            return FileNames.boardPlayer
        case .settings:
            return FileNames.settings
        case .shipSets:
            return FileNames.shipSets
        case .gameDefinitions:
            return FileNames.gameDefinitions
        default:
            return nil
        }
    }
}

extension StorageFile {
    private struct ShipSetStorage: Codable {
        var ships = [Int:Int]()
        let name: String?
        let description: String?
        let uuid: UUID
        
        init(name: String?, description:String?, uuid: UUID, ships: [Int:Int]) {
            self.name = name
            self.description = description
            self.uuid = uuid
            self.ships.merge(ships) { (_, new) in new }
        }
    }
}

//
//  VC_Play_Opponent_Ships.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 21/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class VC_Play_Opponent_Ships: UIViewController {

    @IBOutlet weak var textFieldRow: UITextField!
    @IBOutlet weak var textFieldColumn: UITextField!
    @IBOutlet weak var labelMessage: UILabel!
    @IBOutlet weak var buttonShoot: UIButton!
    @IBOutlet weak var viewGameBoard: V_GameBoard!
    @IBOutlet weak var sliderRowSelect: UISlider!
    @IBOutlet weak var sliderColumnSelect: UISlider!
    
    private var managerGame = ManagerGame.sharedInstance
    private var managerSettings = ManagerSettings.sharedInstance
    
    var vcPlay: VC_Play!
    
    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldRow.delegate = self
        textFieldColumn.delegate = self
        textFieldRow.text = "1"
        textFieldColumn.text = "1"
        viewGameBoard.who = EngineGameBattleship.Who.opponent
        managerGame.opponentViewGameBoard = viewGameBoard
        sliderRowSelect.minimumValue = 1
        sliderRowSelect.maximumValue = Float(managerGame.rows)
        sliderColumnSelect.minimumValue = 1
        sliderColumnSelect.maximumValue = Float(managerGame.columns)
        labelMessage.text = ""
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    @objc func textFieldUserStoppedTyping(sender: UITextField) {
        actionAfterRowOrColumnChanged(updateSlider: true)
    }
    
    @IBAction func buttonFinishPress(_ sender: UIButton) {
        // Used by unwind segue
    }
    
    @IBAction func buttonShootPress(_ sender: UIButton) {
        if managerGame.playLoopStage == .playerShoot {
            if let row = textFieldRow.text,
                let column = textFieldColumn.text
            {
                if !row.isEmpty && !column.isEmpty {
                    //print(StaticVariable.Info + ": player shot at \(row) and \(column)")
                    if let r = Int(row),
                        let c = Int(column) {
                    
                        if r < 1 || r > managerGame.rows {
                            // BEGIN action dialog
                            let message = String.localizedStringWithFormat(AppStrings.shotCoordinatesOutOfRange,
                                                                           AppStrings.row)
                            
                            let alert = UIAlertController(title: AppStrings.information,
                                                          message: message,
                                                          preferredStyle: .alert)
                            
                            alert.addAction(UIAlertAction(title: AppStrings.ok,
                                                          style: .default,
                                                          handler: { (_) in
                            }))
                            
                            self.present(alert, animated: true, completion: nil)
                            // END action dialog
                        }
                        else if c < 1 || c > managerGame.columns {
                            // BEGIN action dialog
                            let message = String.localizedStringWithFormat(AppStrings.shotCoordinatesOutOfRange,
                                                                           AppStrings.column)
                            
                            let alert = UIAlertController(title: AppStrings.information,
                                                          message: message,
                                                          preferredStyle: .alert)
                            
                            alert.addAction(UIAlertAction(title: AppStrings.ok,
                                                          style: .default,
                                                          handler: { (_) in
                            }))
                            
                            self.present(alert, animated: true, completion: nil)
                            // END action dialog
                        }
                        
                        if managerGame.engine.mayShot(who: .player, row: r, col: c) {
                            //print(StaticVariable.Info + ": player shot at row \(r) and column \(c)")
                            let result = managerGame.engine.shot(who: .player, row: r, col: c)
                            if result.result == EngineGameBattleship.ShotResult.miss {
                                managerGame.messageToDisplayInNextView = AppStrings.shootResultMissed
                            } else if result.result == EngineGameBattleship.ShotResult.hit {
                                managerGame.messageToDisplayInNextView = AppStrings.shootResultHit
                                
                                if managerSettings.settings.getInformationHit() == .full {
                                    let extraInfo = shipInfoForMessage(ship: result.ship!)
                                    managerGame.messageToDisplayInNextView += " (\(extraInfo))"
                                }
                            } else if result.result == EngineGameBattleship.ShotResult.destroy {
                                managerGame.messageToDisplayInNextView = AppStrings.shootResultDestroyed
                            }
                            //managerGame.refreshViewGameBoard(whoseBoard: .opponent)
                            managerGame.tryCoordinates = nil
                            vcPlay.nextStage()
                        } else {
                            // BEGIN action dialog
                            let alert = UIAlertController(title: AppStrings.information,
                                                          message: AppStrings.cantShootAtThisField,
                                                          preferredStyle: .alert)
                            
                            alert.addAction(UIAlertAction(title: AppStrings.ok,
                                                          style: .default,
                                                          handler: { (_) in
                            }))
                            
                            self.present(alert, animated: true, completion: nil)
                            // END action dialog
                        }
                    }
                } else {
                    // BEGIN action dialog
                    let alert = UIAlertController(title: AppStrings.information,
                                                  message: AppStrings.incorrectShotCoordinates,
                                                  preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: AppStrings.ok,
                                                  style: .default,
                                                  handler: { (_) in
                    }))
                    
                    self.present(alert, animated: true, completion: nil)
                    // END action dialog
                }
            }
        } else if managerGame.playLoopStage == .playerShotResults {
            let coordinates = managerGame.engine.getShotCoordinatesForOpponent(maxTries: 100)
            if coordinates == nil {
                print(StaticVariable.Error + ": Opponent can't shoot")
            } else {
                //print(StaticVariable.Info + ": opponent shot at row \(coordinates!.row) and column \(coordinates!.col)")
                let result = managerGame.engine.shot(who: .opponent,
                                                     row: coordinates!.row,
                                                     col: coordinates!.col)
                if result.result == EngineGameBattleship.ShotResult.miss {
                    managerGame.messageToDisplayInNextView = AppStrings.shootResultMissed
                } else if result.result == EngineGameBattleship.ShotResult.hit {
                    managerGame.messageToDisplayInNextView = AppStrings.shootResultHit
                    
                    if managerSettings.settings.getInformationHit() == .full {
                        let extraInfo = shipInfoForMessage(ship: result.ship!)
                        managerGame.messageToDisplayInNextView += " (\(extraInfo))"
                    }
                } else if result.result == EngineGameBattleship.ShotResult.destroy {
                    managerGame.messageToDisplayInNextView = AppStrings.shootResultDestroyed
                }
                //managerGame.refreshViewGameBoard(whoseBoard: .player)
                vcPlay.nextStage()
            }
        }
    }
    
    @IBAction func sliderRowSelectValueChanged(_ sender: UISlider) {
        textFieldRow.text = "\(Int(sliderRowSelect.value.rounded(.down)))"
        actionAfterRowOrColumnChanged(updateSlider: false)
    }
    
    @IBAction func sliderColumnSelectValueChanged(_ sender: UISlider) {
        textFieldColumn.text = "\(Int(sliderColumnSelect.value.rounded(.down)))"
        actionAfterRowOrColumnChanged(updateSlider: false)
    }
    // END Actions
    
    // MARK: - My functions
    // BEGIN My functions
    func actionAfterRowOrColumnChanged(updateSlider: Bool) {
        
        if let row = textFieldRow.text,
            let column = textFieldColumn.text
        {
            if !row.isEmpty && !column.isEmpty {
                if let r = Int(row),
                    let c = Int(column) {
                
                    if r >= 1 && r <= managerGame.rows && c >= 1 && c <= managerGame.columns {
                        managerGame.tryCoordinates = (row: r, column: c)
                        if updateSlider {
                            sliderRowSelect.setValue(Float(r), animated: true)
                            sliderColumnSelect.setValue(Float(c), animated: true)
                        }
                        viewGameBoard.setNeedsDisplay()
                    }
                }
            }
        }
    }
    
    private func shipInfoForMessage(ship: Ship) -> String {
        var remain = 0
        var total = 0
        for section in ship.position {
            total += 1
            if (section.status == Ship.Status.ready) {
                remain += 1
            }
        }
        let extraInfo = String.localizedStringWithFormat(AppStrings.reportAfterHit,
                                                         "\(remain)",
                                                         "\(total)")
        return extraInfo
    }
    
    func updateMessage() {
        labelMessage.text = managerGame.messageToDisplayInNextView
    }
    // END My functions
}

extension VC_Play_Opponent_Ships: UITextFieldDelegate {
    func textField(_ textField: UITextField,
                   shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool
    {
        if string.count > 0 &&
            string.rangeOfCharacter(from: NSCharacterSet.decimalDigits) == nil {
            return false
        }
        
        NSObject.cancelPreviousPerformRequests(
            withTarget: self,
            selector: #selector(textFieldUserStoppedTyping),
            object: textField)
        self.perform(
            #selector(textFieldUserStoppedTyping),
            with: textField,
            afterDelay: 0.25)

        return true
    }
}

//
//  TVC_GameDefinitions.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 08/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class TVC_GameDefinitions: UITableViewController {
    @IBOutlet weak var barButtonMove: UIBarButtonItem!
    @IBOutlet weak var barButtonAdd: UIBarButtonItem!
    
    private var managerSettings = ManagerSettings.sharedInstance
    var viewMode = ViewMode.undefined
    var indexGameDefinition: Int?
    
    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        switch viewMode {
        case .editable:
            barButtonMove.isEnabled = true
            barButtonAdd.isEnabled = true
        case .noneditable:
            barButtonMove.isEnabled = false
            barButtonAdd.isEnabled = false
        default:
            print(StaticVariable.Warning + ": Bad view mode")
        }
        
        indexGameDefinition = nil
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == StaticVariable.SegueFromGameDefinitionsToGameDefinition) {
            if let destVC = segue.destination as? VC_GameDefinition {
                if let sender = sender {
                    if sender is TVC_GameDefinitions {
                        destVC.viewMode = .edit
                        destVC.indexGameDefinition = indexGameDefinition
                        destVC.parentController = self
                    }
                    else if sender is UIBarButtonItem {
                        destVC.viewMode = .add
                        destVC.indexGameDefinition = nil
                        destVC.parentController = self
                    }
                }
            }
        }
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return managerSettings.gameDefinitions.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: StaticVariable.ListCellGameDefinition)
        
        if cell == nil {
            cell = UITableViewCell(style: .subtitle,
                                   reuseIdentifier: StaticVariable.ListCellGameDefinition)
        }
        
        cell?.textLabel?.text = managerSettings.gameDefinitions[indexPath.row].name
        cell?.detailTextLabel?.text = managerSettings.gameDefinitions[indexPath.row].description

        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if viewMode == .noneditable {
            if indexGameDefinition == indexPath.row {
                indexGameDefinition = nil
                if let cell = tableView.cellForRow(at: indexPath) as? UITableViewCell {
                    cell.isSelected = false
                }
            } else {
                indexGameDefinition = indexPath.row
            }
        } else if viewMode == .editable {
            indexGameDefinition = indexPath.row
            self.performSegue(withIdentifier: StaticVariable.SegueFromGameDefinitionsToGameDefinition, sender: self)
        }
    }
    
    override func tableView(_ tableView: UITableView,
                   trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        guard viewMode == .editable else {return nil}
        
        let actionDelete = UIContextualAction(style: .destructive,
                                              title:  AppStrings.delete,
                                              handler:
            {(action:UIContextualAction, view:UIView, completionHandler:(Bool) -> Void) in
                self.managerSettings.shipSets.remove(at: indexPath.row)
                tableView.reloadData()
                
                completionHandler(true)
        }
        )
        actionDelete.backgroundColor = .red
        
        let configuration = UISwipeActionsConfiguration(actions: [actionDelete])
        configuration.performsFirstActionWithFullSwipe = false
        return configuration
    }
    
    override func tableView(_ tableView: UITableView,
                            editingStyleForRowAt indexPath: IndexPath
    ) -> UITableViewCell.EditingStyle {
        return .none
    }
    
    override func tableView(_ tableView: UITableView,
                            shouldIndentWhileEditingRowAt indexPath: IndexPath
    ) -> Bool {
        return false
    }
    
    override func tableView(_ tableView: UITableView,
                            canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView,
                            moveRowAt sourceIndexPath: IndexPath,
                            to destinationIndexPath: IndexPath) {
        
        let set = self.managerSettings.gameDefinitions.remove(at: sourceIndexPath.row)
        self.managerSettings.gameDefinitions.insert(set, at: destinationIndexPath.row)
        
        tableView.reloadData()
    }
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    @IBAction func barButtonReorderPress(_ sender: UIBarButtonItem) {
        self.tableView.isEditing = !self.tableView.isEditing
    }
    /*
    @objc func menuAction(){
        dismiss(animated: true, completion: nil)
    }
    */
    // END Actions
    
    // MARK: - My functions
    // BEGIN My functions
    // From:
    // https://stackoverflow.com/questions/21889145/add-a-left-bar-button-item-to-uinavigationcontroller-when-no-back-button-is-pres
    // https://medium.com/simple-swift-programming-tips/how-to-make-custom-uinavigationcontroller-back-button-image-without-title-swift-7ea5673d7e03
    // Remark:
    // To make the following working
    //self.navigationItem.backBarButtonItem = backButton
    // this should be set in previous controller.
    // See:
    // If ViewController A push ViewController B meanwhile we want to set
    // the back bar button tittle, we should set
    // "self.navigationItem.backBarButtonItem = ..".if it was set
    // in ViewController B, it will not work as we want.
    // in
    // https://stackoverflow.com/questions/4964276/navigationitem-backbarbuttonitem-not-working-why-is-the-previous-menu-still-sho
    // and also
    // If you are setting the back button for the current view controller's
    // navigation item you are not setting the button that get's displayed
    // in the current view. You are in fact setting the back button that will be
    // used if you push another view controller from it.
    // in
    // https://stackoverflow.com/questions/31217025/self-navigationitem-backbarbuttonitem-title-back-does-not-work-for-the-next-v?lq=1
    /*
    private func addNavigationItemBackButton(){
        let backButton = UIBarButtonItem(title: AppStrings.back,
                                         style: .plain,
                                         target: self,
                                         action: #selector(menuAction))
        self.navigationItem.leftBarButtonItem = backButton
    }
 */
    // END My functions
}

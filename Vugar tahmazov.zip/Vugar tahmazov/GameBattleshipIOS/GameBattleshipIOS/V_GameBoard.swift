//
//  V_GameBoard.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 01/05/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

//@IBDesignable
class V_GameBoard: UIView {
    private var managerGame = ManagerGame.sharedInstance
    
    var who: EngineGameBattleship.Who!
    var borderColor = GameColors.grayLight
    
    var drawingAreaRect: CGRect {
        let outerBorderThick = CGFloat(10.0)
        var dx, dy: CGFloat
        
        if(bounds.width > bounds.height){
            dx = outerBorderThick + (bounds.width-bounds.height)/2
            dy = outerBorderThick
        } else {
            dx = outerBorderThick
            dy = outerBorderThick + (bounds.height-bounds.width)/2
        }
        
        let width = Double(bounds.width - 2 * dx)
        let height = Double(bounds.height - 2 * dy)
        let cols = Double(managerGame.columns)
        let rows = Double(managerGame.rows)
        var cellW = width / cols
        var cellH = height / rows
        
        if cellW > cellH {
            cellW = cellH
        } else {
            cellH = cellW
        }
        
        dx += CGFloat((width - cols * cellW)/2.0)
        dy += CGFloat((height - rows * cellH)/2.0)
        
        return bounds.insetBy(
            dx: dx,
            dy: dy)
    }
    
    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func draw(_ rect: CGRect) {
        var path = UIBezierPath(rect: rect)
        borderColor.setFill()
        path.fill()
        
        let boardArea = drawingAreaRect
        let drawingArea = UIBezierPath(rect: boardArea)
        GameColors.white.setFill()
        drawingArea.fill()
        
        let width = Double(boardArea.width)
        let height = Double(boardArea.height)
        let cols = managerGame.columns
        let rows = managerGame.rows
        let cellW = width / Double(cols)
        let cellH = height / Double(rows)
        let x0 = Double(boardArea.minX)
        let y0 = Double(boardArea.minY)

        var board = managerGame.engine.boardPlayer
        if who == EngineGameBattleship.Who.opponent {
            board = managerGame.engine.boardOpponent
        }
        
        for r in 1...rows {
            for c in 1...cols {
                // In iOS coordinates are of ULC (upper left corner) type
                // In macOS we have LLC (lower left corner) so we shoud use
                // y: y0 + Double(rows-r)*cellH,
                drawCell(rect: CGRect(x: x0 + Double(c-1)*cellW,
                                      y: y0 + Double(r-1)*cellH,
                                      width: cellW,
                                      height: cellH),
                         boardCellType: board.board[r][c])
                //print("\(r) \(c) \(board.board[r][c])")
            }
        }
        
        path = UIBezierPath()
        
        for r in 0...rows {
            path.move(to: CGPoint(x: x0 + 0, y: y0 + Double(r)*cellH))
            path.addLine(to: CGPoint(x: x0 + width, y: y0 + Double(r)*cellH))
        }
        
        for c in 0...cols {
            path.move(to: CGPoint(x: x0 + Double(c)*cellW, y: y0 + 0))
            path.addLine(to: CGPoint(x: x0 + Double(c)*cellW, y: y0 + height))
        }
        
        GameColors.black.set()
        path.lineWidth = 1.0
        path.stroke()
        
        if who == EngineGameBattleship.Who.opponent {
            if let tryCoordinates =  managerGame.tryCoordinates {
                path = UIBezierPath(ovalIn: CGRect(x: x0 + Double(tryCoordinates.column-1)*cellW - 3,
                                                   y: y0 + Double(tryCoordinates.row-1)*cellH - 3,
                                                   width: cellW + 6,
                                                   height: cellH + 6))
                GameColors.yellow.set()
                path.lineWidth = 6.0
                path.stroke()
            }
        }
    }
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    
    // END Actions
    
    // MARK: - My functions
    // BEGIN My functions
    private func drawCell(rect: CGRect, boardCellType: Board.CellType)
    {
        var cellColor = GameColors.blueLight
        
        switch boardCellType {
        case .destroyed:
            cellColor = GameColors.grayLight
        case .empty:
            cellColor = GameColors.blueLight
        case .hit:
            cellColor = GameColors.red
        case .ship:
            if who == EngineGameBattleship.Who.player {
                cellColor = GameColors.gray
            } else {
//                cellColor = GameColors.gray
                cellColor = GameColors.blueLight
            }
        case .shot:
            cellColor = GameColors.blueDark
        case .none:
            cellColor = GameColors.white
        case .notAllowed:
            cellColor = GameColors.blueLight
        case .rescue:
            cellColor = GameColors.orange
        }
        
        let path = UIBezierPath(rect: rect)
        cellColor.setFill()
        path.fill()
    }
    // END My functions
}

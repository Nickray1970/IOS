//
//  ManagerGame.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 01/05/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class ManagerGame {
    static let sharedInstance = ManagerGame()
    
    var engine: EngineGameBattleship!
    var rows: Int = 0
    var columns: Int = 0
    var opponentViewGameBoard: V_GameBoard!
    var playerViewGameBoard: V_GameBoard!
    var tryCoordinates: (row: Int, column: Int)?
    
    // This data is moved here from VC_Play as it is neede
    // to save and restor game state (along with boards, ships, etc.)
    var playLoopStage = VC_Play.PlayLoopStage.undefined
    var visibleView = VC_Play.VisibleView.opponentShips
    var messageToDisplayInNextView = ""
    
    init() {
    }
    
    func createGame(rows: Int = 10, cols: Int = 10, shipsSize: [Int]) {
        self.rows = rows
        self.columns = cols
        engine = EngineGameBattleship(rows: rows, cols: cols, shipsSize: shipsSize)
    }
    
    func refreshViewGameBoard(whoseBoard: EngineGameBattleship.Who) {
        if whoseBoard == .player {
            playerViewGameBoard.setNeedsDisplay()
        } else {
            opponentViewGameBoard.setNeedsDisplay()
        }
    }
    
    func restoreGameEngine(boardPlayer: Board, boardOpponent: Board) {
        rows = boardPlayer.board.count-2
        columns = boardPlayer.board[0].count-2
        engine = EngineGameBattleship(rows: rows, cols: columns, boardPlayer: boardPlayer, boardOpponent: boardOpponent)
    }
}

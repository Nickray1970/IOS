//
//  ListCellShipSet.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 25/05/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class ListCellShipSet: UITableViewCell {

    @IBOutlet weak var labelInfo: UILabel!
    @IBOutlet weak var imageViewSize: UIImageView!
    @IBOutlet weak var imageViewDigit_1: UIImageView!
    @IBOutlet weak var imageViewDigit_0: UIImageView!
    
    private var shipSize: Int!
    private var number: Int!
    private var info: String?
    
    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    // END Overriden functions
    
    // MARK: - My functions
    // BEGIN My functions
    func initCell(shipSize: Int, number: Int, info: String?) {
        labelInfo.text = info
        
        if !(self.info == info) {
            self.info = info
            labelInfo.text = info
        }
        
        if !(self.shipSize == shipSize) {
            self.shipSize = shipSize
            imageViewSize.image = Assets.getImage(forShipSize: shipSize)!
        }
        
        if !(self.number == number) {
            self.number = number
            
            let digit_0 = number % 10
            let digit_1 = Int(number / 10)
            
            imageViewDigit_0.image = Assets.getImage(forDigit: digit_0)!
            
            if digit_1 > 0 {
                imageViewDigit_1.image = Assets.getImage(forDigit: digit_1)!
            } else {
                imageViewDigit_1.image = nil
            }
        }
    }
    // END My functions
}

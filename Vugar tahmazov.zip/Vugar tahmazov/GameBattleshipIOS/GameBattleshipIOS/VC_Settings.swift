//
//  VC_Settings.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 02/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class VC_Settings: UIViewController {
    @IBOutlet weak var buttonFullInformation: UIButton!
    @IBOutlet weak var buttonHitOrMiss: UIButton!
    
    private var managerSettings = ManagerSettings.sharedInstance
    
    enum RadioState {
        case active, inactive
    }
    
    struct ButtonTag {
        static let buttonFullInformation = 1
        static let buttonHitOrMiss = 2
    }
        
    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttonFullInformation.layer.cornerRadius = 5
        buttonFullInformation.layer.borderWidth = 2.0
        buttonFullInformation.layer.masksToBounds = true
        setButtonColor(button: buttonFullInformation, state: .inactive)
        
        buttonHitOrMiss.layer.cornerRadius = 5
        buttonHitOrMiss.layer.borderWidth = 2.0
        buttonHitOrMiss.layer.masksToBounds = true
        setButtonColor(button: buttonHitOrMiss, state: .inactive)
        
        markRadioButton(which: .full)
    }
    
    override func canPerformUnwindSegueAction(_ action: Selector,
      from fromViewController: UIViewController,
      sender: Any?) -> Bool {
        if let fromVC = fromViewController as? TVC_GameDefinitions {
            if fromVC.viewMode == .editable {
                return true
            }
        } else if let fromVC = fromViewController as? TVC_ShipSets {
            if fromVC.viewMode == .editable {
                return true
            }
        }
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == StaticVariable.SegueFromSettingsToShipSets) {
            // targetController TVC_ShipSets is "hidden" behind destVC UINavigationController
            if let destVC = segue.destination as? UINavigationController,
                let targetController = destVC.topViewController as? TVC_ShipSets {
                targetController.viewMode = .editable
            }
        } else if (segue.identifier == StaticVariable.SegueFromSettingsToGameDefinitions) {
            if let destVC = segue.destination as? UINavigationController,
                let targetController = destVC.topViewController as? TVC_GameDefinitions {
                targetController.viewMode = .editable
            }
        }
    }
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    @IBAction func buttonRadioInformationPress(_ sender: UIButton) {
        if sender.tag == ButtonTag.buttonFullInformation {
            if managerSettings.settings.getInformationHit() != .full {
                markRadioButton(which: .full)
            }
        } else if sender.tag == ButtonTag.buttonHitOrMiss {
            if managerSettings.settings.getInformationHit() != .hitOrMiss {
                markRadioButton(which: .hitOrMiss)
            }
        }
    }
    
    @IBAction func unwindFromShipSets(segue: UIStoryboardSegue){}
    
    @IBAction func unwindFromGameDefinitions(segue: UIStoryboardSegue){}
    // END Actions
    
    // MARK: - My functions
    // BEGIN My functions
    private func markRadioButton(which: ManagerSettings.InformationHit) {
        // Unchecked what is marked
        let informationHit = managerSettings.settings.getInformationHit()
        if informationHit == .full {
            setButtonColor(button: buttonFullInformation, state: .inactive)
        } else if informationHit == .hitOrMiss {
            setButtonColor(button: buttonHitOrMiss, state: .inactive)
        }
        
        // Mark "which" button
        if which == .full {
            setButtonColor(button: buttonFullInformation, state: .active)
        } else if which == .hitOrMiss {
            setButtonColor(button: buttonHitOrMiss, state: .active)
        }
        
        // If needed, save
        if which != informationHit {
            managerSettings.settings.setInformationHit(value: which)
            managerSettings.saveSettings()
        }
    }
    
    private func setButtonColor(button: UIButton, state: RadioState) {
        var color: UIColor?
        
        switch state {
        case .active:
            color = UIColor.systemGreen
        case .inactive:
            color = UIColor.systemGray
        }
        
        if let color = color {
            button.layer.borderColor = color.cgColor
            button.setTitleColor(color, for: .normal)
        }
    }
    // END My functions
}

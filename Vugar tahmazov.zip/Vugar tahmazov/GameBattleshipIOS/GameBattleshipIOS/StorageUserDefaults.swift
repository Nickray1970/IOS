//
//  GameSave.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 18/05/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class StorageUserDefaults {
    static let sharedInstance = StorageUserDefaults()
    let defaults = UserDefaults.standard
    
    struct Key {
        static let playLoopStage = "playLoopStage"
        static let visibleView = "visibleView"
        static let messageToDisplayInNextView = "messageToDisplayInNextView"
    }
    
    func delete(forKey: String) {
        defaults.removeObject(forKey: forKey)
    }
    
    func save(value: Int, forKey: String) {
        if forKey == Key.playLoopStage ||
            forKey == Key.visibleView {
            defaults.set(value, forKey: forKey)
        } else {
            return
        }
    }
    
    func save(value: String, forKey: String) {        
        if forKey == Key.messageToDisplayInNextView {
            defaults.set(value, forKey: forKey)
        } else {
            return
        }
    }
    
    func loadInt(forKey: String) -> Int? {
        if (defaults.object(forKey: forKey) != nil) {
            // If the specified key doesn‘t exist, this method returns 0.
            return defaults.integer(forKey: forKey)
        }
        
        return nil
    }
    
    func loadString(forKey: String) -> String? {
        if (defaults.object(forKey: forKey) != nil) {
            //Returns nil if the default does not exist
            //or is not a string or number value.
            return defaults.string(forKey: forKey)
        }
        
        return nil
    }
}

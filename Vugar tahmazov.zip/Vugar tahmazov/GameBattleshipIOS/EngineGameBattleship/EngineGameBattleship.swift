//
//  EngineGameBattleship.swift
//  GameBattleshipTerminal
//
//  Created by Piotr Fulmański on 2020.02.26.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class EngineGameBattleship {
    private var shipsSize: [Int]!
    private var rows, cols: Int
    
    var boardPlayer: Board
    var boardOpponent: Board
    
    enum Who {
        case player, opponent
    }
    
    enum ShotResult {
        case unknown, hit, miss, destroy
    }
    
    init(rows: Int, cols: Int, boardPlayer: Board, boardOpponent: Board) {
        self.rows = rows
        self.cols = cols
        self.boardPlayer = boardPlayer
        self.boardOpponent = boardOpponent
    }

    init(rows: Int = 10, cols: Int = 10, shipsSize: [Int]) {
        self.boardPlayer = Board(rows: rows, cols: cols)
        self.boardOpponent = Board(rows: rows, cols: cols)
        
        self.shipsSize = shipsSize
        
        self.rows = rows
        self.cols = cols
    }
    
    func checkWhoWins() -> Who? {
        if boardPlayer.ships.shipsAtCommand == 0 {
            return Who.opponent
        } else if boardOpponent.ships.shipsAtCommand == 0 {
            return Who.player
        }
        
        return nil
    }
    
    func getShotCoordinatesForOpponent(maxTries: Int) -> (row: Int, col: Int)? {
        var row, col: Int?
        
        // Use random approach
        for _ in 1...maxTries {
            row = EngineGameBattleshipUtils.getRandomInt(from: 1, to: rows)
            col = EngineGameBattleshipUtils.getRandomInt(from: 1, to: cols)
            
            if let r = row, let c = col {
                if mayShot(who: Who.opponent, row: r, col: c) {
                    return (row: r, col: c)
                }
            }
        }
        
        // If previous failed, use systematic search approach
        for r in 0...rows+1 {
            for c in 0...cols+1 {
                if mayShot(who: Who.opponent, row: r, col: c) {
                    return (row: r, col: c)
                }
            }
        }
        
        return nil
    }
    
    func mayPlaceShip(who: Who, size: Int, anchorRow: Int, anchorCol: Int, direction: Ship.Direction) -> Bool {
        
        let anchor = (row: anchorRow, col: anchorCol)
        let boardWho = getWhoBoard(who: who)
        return boardWho.mayPlaceShip(size: size,
                                 anchor: anchor,
                                 direction: direction)
    }
    
    func mayShot(who: Who, row: Int, col: Int) -> Bool {
        let boardWho = getWhoBoard(who: getWhoTarget(who: who))
        return boardWho.mayShot(row: row, col: col)
    }
    
    func placeShip(who: Who, size: Int, anchorRow: Int, anchorCol: Int, direction: Ship.Direction) {
        let anchor = (row: anchorRow, col: anchorCol)
        let boardWho = getWhoBoard(who: who)
        boardWho.placeShip(size: size, anchor: anchor, direction: direction)
    }
    
    func shot(who: Who, row: Int, col: Int) -> (result: EngineGameBattleship.ShotResult, ship: Ship?) {
        let boardWho = getWhoBoard(who: getWhoTarget(who: who))
        return boardWho.shot(row: row, col: col)
    }
    
    func shipsAutoSetup(maxTriesPerShip: Int, who: Who) -> Bool {
        let boardWho = getWhoBoard(who: who)
        let number = boardWho.shipsAutoSetup(shipsSize: shipsSize, maxTriesPerShip: maxTriesPerShip)
        
        if shipsSize.count == number {
            return true
        }
        
        return false
    }
    
    private func getWhoBoard(who: Who) -> Board {
        if who == Who.player {
            return boardPlayer
        }

        return boardOpponent
    }
    
    private func getWhoTarget(who: Who) -> Who {
        if who == Who.player {
            return Who.opponent
        }
        return Who.player
    }
    
    func printBoards() {
        print("PLAYER")
        boardPlayer.printBoard()
        print("OPPONENT")
        boardOpponent.printBoard()
    }
}

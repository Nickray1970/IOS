//
//  EngineGameBattleshipUtils.swift
//  GameBattleshipTerminal
//
//  Created by Piotr Fulmański on 2020.03.02.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class EngineGameBattleshipUtils {
    class func determineNumberOfdigits(number: Int) -> Int {
        var value = 10

        guard number > 0 else {return 0}

        for digits in 1...10 {
            if (value > number) {
                return digits
            }
            value *= 10
        }

        return 0
    }
    
    class func getRandomInt(from: Int, to: Int, excluding: [Int]? = nil) -> Int? {
        let maxTries = 10
        var candidate = -1
        
        if from == to {
            return from
        }
        
        for _ in 0 ..< maxTries {
            candidate = Int.random(in: from ... to)
            
            if excluding != nil {
                if !excluding!.contains(candidate) {
                    return candidate
                }
            } else {
                return candidate
            }
        }
        
        return nil
    }
}

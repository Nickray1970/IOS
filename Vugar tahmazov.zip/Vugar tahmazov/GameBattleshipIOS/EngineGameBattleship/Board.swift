//
//  Board.swift
//  GameBattleshipTerminal
//
//  Created by Piotr Fulmański on 2020.02.26.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class Board: Codable {
    private let rows, cols: Int
    var board: [[CellType]]
    var ships: Ships

    enum CellType: Int {
        case none=0, destroyed=1, empty=2, hit=3, notAllowed=4, rescue=5, ship=6, shot=7
    }
    
    init (rows: Int, cols: Int) {
        self.rows = rows
        self.cols = cols
        
        board = Array(repeating: Array(repeating: .none, count: cols+2), count: rows+2)
        ships =  Ships()
        prepareBoard()
    }
    
    func prepareBoard() {
        for i in 0...rows+1 {
            board[i][0] = .notAllowed
            board[i][cols+1] = .notAllowed
        }
        
        for i in 0...cols+1 {
            board[0][i] = .notAllowed
            board[rows+1][i] = .notAllowed
        }
        
        for r in 1...rows {
            for c in 1...cols {
                board[r][c] = .empty
            }
        }
    }
    
    func placeShip(size: Int, anchor: (row: Int, col: Int), direction: Ship.Direction) {
        var modifier: (forRow: Int, forCol: Int)!
        var r: Int!
        var c: Int!
        var position = [Ship.Position]()
        
        switch direction {
        case .up:
            modifier = (forRow: -1, forCol:  0)
        case .down:
            modifier = (forRow: +1, forCol:  0)
        case .left:
            modifier = (forRow:  0, forCol: -1)
        case .right:
            modifier = (forRow:  0, forCol: +1)
        }
        
        for i in 0...size-1 {
            r = anchor.row + i*modifier.forRow
            c = anchor.col + i*modifier.forCol
            
            board[r][c] = CellType.ship
            position.append(Ship.Position(row: r,
                                          column: c,
                                          status: .ready))
            
            // BEGIN: To add border along ship
            r = anchor.row+(modifier.forCol) + i*modifier.forRow
            c = anchor.col+(modifier.forRow) + i*modifier.forCol
            board[r][c] = .notAllowed
            
            r = anchor.row-(modifier.forCol) + i*modifier.forRow
            c = anchor.col-(modifier.forRow) + i*modifier.forCol
            board[r][c] = .notAllowed
            // END: To add border along ship
        }
        
        // BEGIN: To add borders at the ends of ship
        // Next to anchor
        r = anchor.row + (-1)*modifier.forRow
        c = anchor.col + (-1)*modifier.forCol
        board[r][c] = .notAllowed
        
        r = anchor.row+(modifier.forCol) + (-1)*modifier.forRow
        c = anchor.col+(modifier.forRow) + (-1)*modifier.forCol
        board[r][c] = .notAllowed
        
        r = anchor.row-(modifier.forCol) + (-1)*modifier.forRow
        c = anchor.col-(modifier.forRow) + (-1)*modifier.forCol
        board[r][c] = .notAllowed
        
        // Next to anchor opposit end
        r = anchor.row + (size)*modifier.forRow
        c = anchor.col + (size)*modifier.forCol
        board[r][c] = .notAllowed
        
        r = anchor.row+(modifier.forCol) + (size)*modifier.forRow
        c = anchor.col+(modifier.forRow) + (size)*modifier.forCol
        board[r][c] = .notAllowed
        
        r = anchor.row-(modifier.forCol) + (size)*modifier.forRow
        c = anchor.col-(modifier.forRow) + (size)*modifier.forCol
        board[r][c] = .notAllowed
        // END: To add borders at the ends of ship
        
        ships.ships["\(anchor)"] = Ship(size: size, position: position)
    }

    func mayPlaceShip(size: Int, anchor: (row: Int, col: Int), direction: Ship.Direction) -> Bool {
        var modifier: (forRow: Int, forCol: Int)!
        var r: Int!
        var c: Int!
        
        switch direction {
        case .up:
            modifier = (forRow: -1, forCol:  0)
        case .down:
            modifier = (forRow: +1, forCol:  0)
        case .left:
            modifier = (forRow:  0, forCol: -1)
        case .right:
            modifier = (forRow:  0, forCol: +1)
        }
        
        for i in 0...size-1 {
            r = anchor.row + i*modifier.forRow
            c = anchor.col + i*modifier.forCol
            
            guard r>0, r<rows+1 else {return false}
            guard c>0, c<cols+1 else {return false}
            
            if board[r][c] != .empty {
                return false
            }
        }
        
        return true
    }
    
    private func markWhenShipDestroyed(ship: Ship) {
        let allCellsArround = [(rowModifier: -1, colModifier:  0),// top
            (rowModifier: -1, colModifier: +1),// top-right
            (rowModifier:  0, colModifier: +1),// right
            (rowModifier: +1, colModifier: +1),// bottom-right
            (rowModifier: +1, colModifier:  0),// bottom
            (rowModifier: +1, colModifier: -1),// bottom-left
            (rowModifier:  0, colModifier: -1),// left
            (rowModifier: -1, colModifier: -1)// top-left
        ]
        
        var row, col: Int
        
        for p in ship.position {
            board[p.row][p.column] = .destroyed
            for modifier in allCellsArround {
                row = p.row + modifier.rowModifier
                col = p.column + modifier.colModifier
                
                let chageToRescue: Set<Board.CellType> = [.empty,
                                                          .shot,
                                                          .notAllowed]
                
                if chageToRescue.contains(board[row][col]) {
                        board[row][col] = Board.CellType.rescue
                }
            }
        }
    }
        
    private func afterHitAction(row: Int, col: Int) -> (result: EngineGameBattleship.ShotResult, ship: Ship?) {
        for (_, ship) in ships.ships {
            if ship.isLocatedAt(row: row, col: col) {
                ship.hitAt(row: row, col: col)
                if ship.isDestroyed {
                    markWhenShipDestroyed(ship: ship)
                    return (result: EngineGameBattleship.ShotResult.destroy, ship)
                }
                return (result: EngineGameBattleship.ShotResult.hit, ship)
            }
        }
        
        return (result: EngineGameBattleship.ShotResult.miss, nil)
    }
    
    func mayShot(row: Int, col: Int) -> Bool {
        let yes: Set<Board.CellType> = [.empty,
                                        .ship,
                                        .notAllowed]
        
        if yes.contains(board[row][col]) {
            return true
        }
        
        let no: Set<Board.CellType> = [.hit,
                                       .rescue,
                                       .shot]
        
        if no.contains(board[row][col]) {
            return false
        }
        
        return false
    }
    
    func shot(row: Int, col: Int) -> (result: EngineGameBattleship.ShotResult, ship: Ship?) {
        if board[row][col] == .empty || board[row][col] == .notAllowed {
            board[row][col] = .shot
            return (result: EngineGameBattleship.ShotResult.miss, nil)
        } else if board[row][col] == .ship {
            board[row][col] = .hit
            return afterHitAction(row: row, col: col)
        }
        
        return (result: EngineGameBattleship.ShotResult.unknown, nil)
    }
    
    func shipsAutoSetup(shipsSize: [Int], maxTriesPerShip: Int) -> Int {
        var shipDirection = Ship.Direction.up
        var possible = true
        var success: Bool
        var positioned = 0
        var anchor: (row: Int, col: Int)
        
        for size in shipsSize {
            success = false
            for _ in 1...maxTriesPerShip {
                if let r = EngineGameBattleshipUtils.getRandomInt(from: 1, to: rows),
                    let c = EngineGameBattleshipUtils.getRandomInt(from: 1, to: cols) {
                
                    anchor = (row: r, col: c)
                
                    if let direction = EngineGameBattleshipUtils.getRandomInt(from: 1, to: 4) {
                        switch direction {
                        case 1: shipDirection = .up
                        case 2: shipDirection = .right
                        case 3: shipDirection = .down
                        default: shipDirection = .left
                        }
                        possible = mayPlaceShip(size: size,
                                                anchor: anchor,
                                                direction: shipDirection)
                
                        if possible {
                            placeShip(size: size,
                                      anchor: anchor,
                                      direction: shipDirection)
                            positioned += 1
                            success = true
                            break
                        }
                    }
                }
            }
            
            if !success {
                return positioned
            }
        }
        
        return positioned
    }
    
    func printBoard() {
        let leadingPadding = EngineGameBattleshipUtils.determineNumberOfdigits(number: rows)
        var leadingPaddingString = ""
        var line = ""
        var digit = 0
        
        for _ in 1...leadingPadding {
            leadingPaddingString += " "
        }
        
        // Cyfry dziesiątek
        line = leadingPaddingString + " "
        for c in 1...cols {
            digit = c/10
            if digit == 0 {
                line += " "
            } else {
                line += "\(digit)"
            }
        }
        
        print(line)
        
        // Cyfry jedności
        line = leadingPaddingString + " "
        for c in 1...cols {
            digit = c%10
            line += "\(digit)"
        }
        
        print(line)
        
        for r in 0...rows+1 {
            line = ""

            if r == 0 || r == rows+1 {
                line += leadingPaddingString
            } else {
                line += String(r).leftPadding(toLength: leadingPadding)
            }
            
            for c in 0...cols+1 {
                switch board[r][c] {
                case .destroyed:
                    line += "#"
                case .empty:
                    line += "."
                case .hit:
                    line += "!"
                case .ship:
                    line += "X"
                case .shot:
                    line += "*"
                case .none:
                    line += "?"
                case .notAllowed:
                    line += "+"
                case .rescue:
                    line += "O"
                }
            }
            
            print(line)
        }
    }
    
}

extension Board.CellType: Codable {
    enum CodingKeys: CodingKey {
        case rawValue
    }
    
    enum CodingError: Error {
        case unknownValue
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let rawValue = try container.decode(Int.self, forKey: .rawValue)
        switch rawValue {
        case 0:
            self = .none
        case 1:
            self = .destroyed
        case 2:
            self = .empty
        case 3:
            self = .hit
        case 4:
            self = .notAllowed
        case 5:
            self = .rescue
        case 6:
            self = .ship
        case 7:
            self = .shot
        default:
            throw CodingError.unknownValue
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        switch self {
        case .none:
            try container.encode(0, forKey: .rawValue)
        case .destroyed:
            try container.encode(1, forKey: .rawValue)
        case .empty:
            try container.encode(2, forKey: .rawValue)
        case .hit:
            try container.encode(3, forKey: .rawValue)
        case .notAllowed:
            try container.encode(4, forKey: .rawValue)
        case .rescue:
            try container.encode(5, forKey: .rawValue)
        case .ship:
            try container.encode(6, forKey: .rawValue)
        case .shot:
            try container.encode(7, forKey: .rawValue)
        }
    }
}


